package com.formation.myapplication.ModelClass;

public class StaticNames
{
    public static String SensorName = "SensorTemp";


    public static String SensorPath = "SensorPath";

    public static String ActualTempPath = "Température actuelle";
    public static String ActualHeatStatePath= "Etat du chauffage";
    public static String CommandPath= "Commande actuelle";



}
