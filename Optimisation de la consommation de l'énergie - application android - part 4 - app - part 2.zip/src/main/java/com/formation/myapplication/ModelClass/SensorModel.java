package com.formation.myapplication.ModelClass;

public class SensorModel
{
    String name;
    String IP;
    float actualTemp;
    float command;

    public SensorModel(String name, String IP, float command, float actualTemp) {
        this.name = name;
        this.IP = IP;
        this.actualTemp = actualTemp;
        this.command= command;
    }

    public float getActualTemp() {
        return actualTemp;
    }

    public void setActualTemp(float actualTemp) {
        this.actualTemp = actualTemp;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIP() {
        return IP;
    }

    public void setIP(String IP) {
        this.IP = IP;
    }

    public float getCommand() {
        return command;
    }

    public void setCommand(float command) {
        this.command = command;
    }
}
