package com.formation.myapplication.ModelClass;

public class SensorDataModel
{
    String IP;
    float CommandTemp;
    float ActualTemp;
    float OutsideTemp;

    public SensorDataModel(String IP, float commandTemp, float actualTemp, float outsideTemp) {
        this.IP = IP;
        CommandTemp = commandTemp;
        ActualTemp = actualTemp;
        OutsideTemp = outsideTemp;
    }

    public String getIP() {
        return IP;
    }

    public void setIP(String IP) {
        this.IP = IP;
    }

    public float getCommandTemp() {
        return CommandTemp;
    }

    public void setCommandTemp(float commandTemp) {
        CommandTemp = commandTemp;
    }

    public float getActualTemp() {
        return ActualTemp;
    }

    public void setActualTemp(float actualTemp) {
        ActualTemp = actualTemp;
    }

    public float getOutsideTemp() {
        return OutsideTemp;
    }

    public void setOutsideTemp(float outsideTemp) {
        OutsideTemp = outsideTemp;
    }
}
