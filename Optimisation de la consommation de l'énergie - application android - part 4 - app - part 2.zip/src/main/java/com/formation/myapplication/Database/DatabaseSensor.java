package com.formation.myapplication.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

import com.formation.myapplication.ModelClass.SensorModel;

import java.util.List;

import static com.formation.myapplication.Database.DatabaseSensor.FeedEntry.TABLE_NAME;

public class DatabaseSensor
{

    private static SensorHelper mDbHelper = null;

    // To prevent someone from accidentally instantiating the contract class,
    // make the constructor private.
    private DatabaseSensor() {
    }

    private static DatabaseSensor instance = null;

    public static DatabaseSensor getInstance(Context context)
    {
        if (instance == null) {
            instance = new DatabaseSensor();
            mDbHelper = new SensorHelper(context);
        }
        return instance;
    }

    public void FillInTheList (List<SensorModel> ListOfSensor)
    {
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        ListOfSensor.clear();
        Cursor cursor = db.rawQuery("select * from " + TABLE_NAME, null);

        while (cursor.moveToNext()) {

            SensorModel sensorModel = new SensorModel(cursor.getString(1),
                    cursor.getString(0), Float.parseFloat(cursor.getString(2)),Float.parseFloat(cursor.getString(3)));

            ListOfSensor.add(sensorModel);

        }
        cursor.close();

    }
    public long addElementTodB(SensorModel sensorModel) {
        SQLiteDatabase db = mDbHelper.getWritableDatabase();
        // Create a new map of values, where column names are the keys
        ContentValues values = new ContentValues();

        values.put(FeedEntry.COLOMN_IP_ADRESS, sensorModel.getIP());
        values.put(FeedEntry.COLOMN_NAME, sensorModel.getName());
        values.put(FeedEntry.COLOMN_COMTEMP, 15);
        values.put(FeedEntry.COLOMN_ACTUALTEMP, 0);


        return db.insert(TABLE_NAME, null, values);
    }
    public Float getActualCommandTemp(String IP)
    {
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        float temp= 0;
        Cursor cursor = db.rawQuery("select * from " + TABLE_NAME + " where " + FeedEntry.COLOMN_IP_ADRESS + "=?", new String[]{IP});

        while (cursor.moveToNext())
        {

            temp = cursor.getFloat(2);
            cursor.close();

            return temp;
        }
        cursor.close();
        return temp;
    }
    public void UpdateCommand (String IP, Float Command) // à rajouter les nouveaux
    {
        SQLiteDatabase db = mDbHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery("select * from " + TABLE_NAME + " where " + FeedEntry.COLOMN_IP_ADRESS+ "=?", new String[]{IP});

        while (cursor.moveToNext()) {


            ContentValues values = new ContentValues();
            values.put(FeedEntry.COLOMN_IP_ADRESS, cursor.getString(0));
            values.put(FeedEntry.COLOMN_NAME, cursor.getString(1));
            values.put(FeedEntry.COLOMN_COMTEMP, Float.toString(Command));
            values.put(FeedEntry.COLOMN_ACTUALTEMP, cursor.getString(3));



            db.update(TABLE_NAME, values, FeedEntry.COLOMN_IP_ADRESS + "=?", new String []{IP});

        }
        cursor.close();

    }
    public void dropDB() {
        SQLiteDatabase db = mDbHelper.getWritableDatabase();
        db.execSQL(SQL_DELETE_ENTRIES);
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    /* Inner class that defines the table contents */
    public static class FeedEntry implements BaseColumns {

        static final String TABLE_NAME = "Sensor";
        static final String COLOMN_IP_ADRESS = "IP";
        static final String COLOMN_NAME = "name";
        static final String COLOMN_COMTEMP = "temperaturecommand";
        static final String COLOMN_ACTUALTEMP = "actualtemp";
    }

    private static final String TEXT_TYPE = " TEXT";
    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    FeedEntry.COLOMN_IP_ADRESS + " TEXT PRIMARY KEY," +
                    FeedEntry.COLOMN_NAME + TEXT_TYPE + "," +
                    FeedEntry.COLOMN_COMTEMP + TEXT_TYPE + "," +
                    FeedEntry.COLOMN_ACTUALTEMP + TEXT_TYPE + " )";

    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + TABLE_NAME;


    private static class SensorHelper extends SQLiteOpenHelper {
        // If you change the database schema, you must increment the database version.
        static final int DATABASE_VERSION = 1;
        static final String DATABASE_NAME = "sensor.db";

        SensorHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        public void onCreate(SQLiteDatabase db) {
            db.execSQL(SQL_CREATE_ENTRIES);
        }

        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // This database is only a cache for online data, so its upgrade policy is
            // to simply to discard the data and start over
            db.execSQL(SQL_DELETE_ENTRIES);
            onCreate(db);
        }

        public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            onUpgrade(db, oldVersion, newVersion);
        }
    }
}

