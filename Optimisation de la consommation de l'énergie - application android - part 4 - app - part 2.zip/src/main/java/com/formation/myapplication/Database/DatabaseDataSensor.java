package com.formation.myapplication.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

import com.formation.myapplication.ModelClass.SensorDataModel;
import com.formation.myapplication.ModelClass.SensorModel;

import java.util.List;

public class DatabaseDataSensor
{

    private static SensorDataHelper mDbHelper = null;

    // To prevent someone from accidentally instantiating the contract class,
    // make the constructor private.
    private DatabaseDataSensor() {
    }

    private static DatabaseDataSensor instance = null;

    public static DatabaseDataSensor getInstance(Context context)
    {
        if (instance == null) {
            instance = new DatabaseDataSensor();
            mDbHelper = new SensorDataHelper(context);
        }
        return instance;
    }

    public void FillInTheList (List<SensorDataModel> ListOfSensor)
    {
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        ListOfSensor.clear();
        Cursor cursor = db.rawQuery("select * from " + FeedEntry.TABLE_NAME, null);

        while (cursor.moveToNext()) {

            SensorDataModel sensorDataModel = new SensorDataModel(cursor.getString(1),
                    Float.parseFloat(cursor.getString(2)), Float.parseFloat(cursor.getString(3)),Float.parseFloat(cursor.getString(4)));

            ListOfSensor.add(sensorDataModel);

        }
        cursor.close();

    }

    public long addElementTodB(SensorDataModel sensorDataModel) {
        SQLiteDatabase db = mDbHelper.getWritableDatabase();
        // Create a new map of values, where column names are the keys
        ContentValues values = new ContentValues();


        values.put(FeedEntry.COLOMN_TIME, System.currentTimeMillis());
        values.put(FeedEntry.COLOMN_IP_ADRESS, sensorDataModel.getIP());
        values.put(FeedEntry.COLUMN_OUTISDETEMP, sensorDataModel.getOutsideTemp());
        values.put(FeedEntry.COLOMN_COMTEMP, sensorDataModel.getCommandTemp());
        values.put(FeedEntry.COLOMN_ACTUALTEMP, sensorDataModel.getActualTemp());


        return db.insert(FeedEntry.TABLE_NAME, null, values);
    }


    public void dropDB() {
        SQLiteDatabase db = mDbHelper.getWritableDatabase();
        db.execSQL(SQL_DELETE_ENTRIES);
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    /* Inner class that defines the table contents */
    public static class FeedEntry implements BaseColumns {

        static final String TABLE_NAME = "Sensor";
        static final String COLOMN_TIME = "time";
        static final String COLOMN_IP_ADRESS = "IP";
        static final String COLOMN_COMTEMP = "temperaturecommand";
        static final String COLOMN_ACTUALTEMP = "actualtemp";
        static final String COLUMN_OUTISDETEMP = "outsidetemp";

    }

    private static final String TEXT_TYPE = " TEXT";
    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + FeedEntry.TABLE_NAME + " (" +
                    FeedEntry.COLOMN_TIME + " TEXT PRIMARY KEY," +
                    FeedEntry.COLOMN_IP_ADRESS + TEXT_TYPE + "," +
                    FeedEntry.COLOMN_COMTEMP + TEXT_TYPE + "," +
                    FeedEntry.COLOMN_ACTUALTEMP + TEXT_TYPE + "," +
                    FeedEntry.COLUMN_OUTISDETEMP + TEXT_TYPE + " )";

    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + FeedEntry.TABLE_NAME;


    private static class SensorDataHelper extends SQLiteOpenHelper {
        // If you change the database schema, you must increment the database version.
        static final int DATABASE_VERSION = 1;
        static final String DATABASE_NAME = "sensordata.db";

        SensorDataHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        public void onCreate(SQLiteDatabase db) {
            db.execSQL(SQL_CREATE_ENTRIES);
        }

        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // This database is only a cache for online data, so its upgrade policy is
            // to simply to discard the data and start over
            db.execSQL(SQL_DELETE_ENTRIES);
            onCreate(db);
        }

        public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            onUpgrade(db, oldVersion, newVersion);
        }
    }
}

