package com.formation.myapplication;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;


import com.formation.myapplication.Database.DatabaseDataSensor;
import com.formation.myapplication.Database.DatabaseSensor;
import com.formation.myapplication.ModelClass.SensorDataModel;
import com.formation.myapplication.ModelClass.SensorModel;
import com.formation.myapplication.ModelClass.StaticNames;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class DashBoardActivity extends AppCompatActivity {


    private RecyclerView recycle_sensor;
    private ListSensorAdapter adapter;
    List<SensorModel> SensorList = new ArrayList<>();
    Toolbar toolbar;
    ChildEventListener SensorListener = new ChildEventListener()
    {
        @Override
        public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s)
        {
              Dealwithdatasnapshot(dataSnapshot);
        }

        @Override
        public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s)
        {
            Dealwithdatasnapshot(dataSnapshot);
        }

        @Override
        public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

        }

        @Override
        public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {

        }
    };

    private void Dealwithdatasnapshot(DataSnapshot dataSnapshot)
    {
        String changedName = dataSnapshot.getKey();
        SensorModel sensorModel = new SensorModel(changedName, "", Float.parseFloat(dataSnapshot.child(StaticNames.CommandPath).getValue().toString()), Float.parseFloat(dataSnapshot.child(StaticNames.ActualTempPath).getValue().toString()));
        for (int i =0; i<SensorList.size(); i++)
        {
            if (changedName.equals(SensorList.get(i).getName())) {
                SensorList.set(i, sensorModel);
                adapter.notifyDataSetChanged();
                break;
            }
            if (i == SensorList.size())
            {
                SensorList.add(sensorModel);
                adapter.notifyDataSetChanged();
            }
        }
        if (SensorList.size() == 0)
        {
            SensorList.add(sensorModel);
            adapter.notifyDataSetChanged();
        }
    }

    private int SensorCheck =0;
     boolean isON = false;






    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);


        //DatabaseSensor.getInstance(this).dropDB();



        SyncFirebase();
        FillInTheList();
        InitializeFields();
        InitializeRecycleView();

    }

    private void FillInTheList()
    {
        DatabaseSensor.getInstance(DashBoardActivity.this).FillInTheList(SensorList);
    }

    private void SyncFirebase()
    {
        FirebaseDatabase.getInstance().getReference().child(StaticNames.SensorPath).addChildEventListener(SensorListener);
    }

    /**  private void RetrieveConstantData()
    {
        FirebaseDatabase.getInstance().getReference().child(StaticNames.SensorName).addChildEventListener(SensorListener);
    }**/

    private void InitializeFields()
    {
        recycle_sensor = (RecyclerView) findViewById(R.id.recycle_checking_captor);
        toolbar = (Toolbar) findViewById(R.id.main_page_toolbar);
        setSupportActionBar(toolbar);

    }

    private void InitializeRecycleView()
    {
      /**  LinearLayoutManager linearLayoutManager = new LinearLayoutManager(DashBoardActivity.this, LinearLayoutManager.VERTICAL, false);
        recycle_sensor.setLayoutManager(linearLayoutManager);
        adapter = new ListSensorAdapter(this, SensorList);
        recycle_sensor.setAdapter(adapter);**/

        GridLayoutManager layoutManager = new GridLayoutManager(DashBoardActivity.this ,2);
        recycle_sensor.setLayoutManager(layoutManager);
        adapter = new ListSensorAdapter(this, SensorList);
        recycle_sensor.setAdapter(adapter);
    }









}
class ListSensorAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Context context;
    List<SensorModel> SensorList = new ArrayList<>();

    public ListSensorAdapter(Context context, List<SensorModel> SensorList)
    {
        this.context = context;
        this.SensorList = SensorList;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.model_sensor, parent, false);
        return new ItemSensorViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position)
    {
      ///  int progression = (int) ((SensorList.get(position).getCommand()/40 )*100);
        ((ItemSensorViewHolder)holder).lbl_name.setText(SensorList.get(position).getName() + "   " + SensorList.get(position).getActualTemp() + "°C");
        ((ItemSensorViewHolder)holder).lbl_value.setText(Float.toString(SensorList.get(position).getCommand()));

        if (SensorList.get(position).getActualTemp() > SensorList.get(position).getCommand())
        {
            ((ItemSensorViewHolder)holder).lbl_value.setBackgroundResource(R.color.colorRed);
        }
        else
        {
            ((ItemSensorViewHolder)holder).lbl_value.setBackgroundResource(R.color.green_count);

        }
       // ((ItemSensorViewHolder) holder).ProgressBar.setProgress((int) (progression));

        ((ItemSensorViewHolder) holder).btn_plus.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Float value = SensorList.get(position).getCommand();
                value = value + 0.5f;
                ChangeDatabaseValue(SensorList.get(position).getName(), value, SensorList.get(position).getIP());
                SensorList.get(position).setCommand(value);
                notifyDataSetChanged();
            }
        });
        ((ItemSensorViewHolder) holder).btn_moins.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Float value = SensorList.get(position).getCommand();
                value = value - 0.5f;
                ChangeDatabaseValue(SensorList.get(position).getName(), value,SensorList.get(position).getIP());
                SensorList.get(position).setCommand(value);
                notifyDataSetChanged();
            }
        });


        if (SensorList.get(position).getCommand() <= 15)
        {
            //Drawable progressDrawable = context.getResources().getDrawable(R.drawable.costumtest);
           // ((ItemSensorViewHolder) holder).ProgressBar.setProgressDrawable(progressDrawable);
        }
        else
        {
           // Drawable progressDrawable = context.getResources().getDrawable(R.drawable.costumtest2);
           // ((ItemSensorViewHolder) holder).ProgressBar.setProgressDrawable(progressDrawable);

        }
    }

    private void ChangeDatabaseValue(String name, Float value, String IP)
    {
        FirebaseDatabase.getInstance().getReference().child(StaticNames.SensorPath

        ).child(name).child(StaticNames.CommandPath).setValue(Float.toString(value));
        DatabaseSensor.getInstance(context).UpdateCommand(IP, value);
    }

    @Override
    public int getItemCount() {
        return SensorList.size();
    }
}

class ItemSensorViewHolder extends RecyclerView.ViewHolder {

    TextView lbl_name ;
    TextView lbl_value;
    ProgressBar ProgressBar;
    Button btn_plus;
    Button btn_moins;

    public ItemSensorViewHolder(View itemView)
    {
        super(itemView);
        lbl_name = itemView.findViewById(R.id.lbl_name);
        lbl_value = itemView.findViewById(R.id.lbl_value);
   //     ProgressBar = itemView.findViewById(R.id.progress_bar);
        btn_plus = itemView.findViewById(R.id.btn_plus);
        btn_moins = itemView.findViewById(R.id.btn_moins);

    }

}
